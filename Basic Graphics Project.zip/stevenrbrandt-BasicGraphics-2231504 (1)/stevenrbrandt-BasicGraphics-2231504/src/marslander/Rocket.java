package marslander;


import basicgraphics.images.Picture;
import basicgraphics.Sprite;
import basicgraphics.SpriteComponent;
import basicgraphics.BasicFrame;
import basicgraphics.ClockWorker;
import basicgraphics.Task;
import basicgraphics.SpriteCollisionEvent;


import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import static java.awt.Color.*;




public class Rocket extends Sprite
{
    Picture rocket;
    private SpriteComponent spriteComponent;
    public Rocket(SpriteComponent sc)
    {
        super(sc);
        BufferedImage image = BasicFrame.createImage(20, 30);


        Graphics g = image.getGraphics();
        int w = image.getWidth();
        int h = image.getHeight();
        g.setColor(Color.BLUE);
        int[] xPoints = {w/2, w, w, 0, 0};
        int[] yPoints = {0, h/3, 2*h/3, 2*h/3, h/3};
        g.fillPolygon(xPoints, yPoints, 5);
        g.drawLine(0, 2*h/3, 0, h);
        g.drawLine(w-1, 2*h/3, w-1, h);



        rocket = new Picture(image);


        setPicture(rocket);
        setX(w / 2);
        setY(h / 2);
        freezeOrientation = true;




     var rocketWithFlame = new Picture(image);
     g.setColor(Color.orange);
     int[] xFlame = {w/4, w/2, 3*w/4};
     int[] yFlame = {2*h/3, h, 2*h/3};

     g.fillPolygon(xFlame, yFlame, 3);
     rocketWithFlame = new Picture(image);

     setPicture(rocketWithFlame);
     setX(w / 2);
     setY(h / 2);

     freezeOrientation = false;

     var task = new Task()
        {
    @Override
    public void run()
     {
    double vx = getVelX();
    double vy = getVelY();
    vy += 0.002;
    setVel(vx, vy);
    }
};
       ClockWorker.addTask(task);






    }


    @Override
    public void processEvent(SpriteCollisionEvent collision)
    {
        Sprite sprite = new Sprite(null);
        SpriteComponent sc = sprite.getSpriteComponent();
        ;

        if (collision.xlo) {
            double screenWidth = sc.getSize().width;
            double rocketWidth = getWidth();
            setX(screenWidth - rocketWidth);
        }

        if (collision.xhi) {
            setX(0);
        }

        if (collision.ylo) {
            JOptionPane.showMessageDialog(sc, "You flew off into space");
            System.exit(0);
        }

        if (collision.yhi) {
            // Collided with the top of the screen
            JOptionPane.showMessageDialog(sc, "You missed the landing pad.");
            System.exit(0);
        }
    }





}

