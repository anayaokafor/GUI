package marslander;


import basicgraphics.BasicFrame;
import basicgraphics.ClockWorker;
import basicgraphics.SpriteComponent;
import basicgraphics.SpriteSpriteCollisionListener;
//import basicgraphics.images.Picture;


import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;


public class MarsLander
{


    public static void main(String[] args) {


        BasicFrame bf = new BasicFrame("Mars Lander");
        SpriteComponent spritecomponent = new SpriteComponent();
        Dimension dimension = new Dimension(800, 400);
        spritecomponent.setPreferredSize(dimension);
        bf.createBasicLayout(spritecomponent);
        LandingPad landingpad = new LandingPad(spritecomponent);
        Rocket rocket = new Rocket(spritecomponent);
        //spritecomponent.addSprite(rocket);
        bf.show();
        ClockWorker.addTask(spritecomponent.moveSprites());
        ClockWorker.initialize(10);


        bf.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {

                int keyCode = e.getKeyCode();


                switch (keyCode) {
                    case KeyEvent.VK_UP:
                        double velX;
                        rocket.setVel(rocket.getVelX(), rocket.getVelY() - 0.4);
                        break;
                    case KeyEvent.VK_LEFT:
                        rocket.setVel(rocket.getVelX() - 0.2, rocket.getVelY());
                        break;
                    case KeyEvent.VK_RIGHT:
                        rocket.setVel(rocket.getVelX() + 0.2, rocket.getVelY());
                        break;
                    default:
                        rocket.setPicture(rocket.getPicture());
                        break;

                }
            }

        });

        spritecomponent.addSpriteSpriteCollisionListener(
                Rocket.class,
                LandingPad.class,
                new SpriteSpriteCollisionListener<Rocket, LandingPad>() {
                    @Override
                    public void collision(Rocket r, LandingPad l) {
                        r.setActive(false);

                        // Check rocket's x velocity
                        double xVelocity = r.getVelX();
                        if (Math.abs(xVelocity) > 0.1) {
                            JOptionPane.showMessageDialog(spritecomponent, "X-Velocity too large! " + xVelocity);
                            return;
                        }

                        // Check rocket's y velocity
                        double yVelocity = r.getVelY();
                        if (yVelocity > 0.4) {
                            JOptionPane.showMessageDialog(spritecomponent, "Y-Velocity too large! " + yVelocity);
                            return;
                        }

                        // If no issues, player wins
                        JOptionPane.showMessageDialog(spritecomponent, "You landed safely! You win!");
                    }
                }
        );


    }

}


