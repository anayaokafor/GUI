package marslander;

import basicgraphics.BasicFrame;
import basicgraphics.Sprite;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;

import java.awt.*;
import java.awt.image.BufferedImage;

public class LandingPad extends Sprite
{
    public LandingPad(SpriteComponent sc)
    {
        super(sc);


        BufferedImage image = BasicFrame.createImage(100, 20);
        Graphics graphics = image.getGraphics();
        graphics.setColor(Color.orange);
        setX(350);
        setY(380);
        graphics.fillRect(0,0, 100, 20);
        Picture p = new Picture(image);
        setPicture(p);


    }




}


